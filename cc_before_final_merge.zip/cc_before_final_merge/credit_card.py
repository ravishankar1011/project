from behave import *
from retry import retry
from hugoutils.utilities.dataclass_util import DataClassParser
from api.distribute.steps.app_dataclass import *
import tests.api.distribute.app_helper as ah
from tests.util.common_util import check_status_distribute
use_step_matcher("re")


@Step("User ([^']*) fetch credit card constants for ([^']*)")
def fetch_credit_card_constants(context, uid,customer):

    request = context.request

    response = request.hugosave_get_request(
        path=ah.credit_card_urls["get_product_config"],
        headers=ah.get_user_header(context,uid),
    )

    if check_status_distribute(response, 200):

        assert "data" in response, (
            f"Expected 'data' in response, got: {response}"
        )

        data = response["data"]

        for field in ["minCreditLimit", "maxCreditLimit", "lienFactor"]:
            assert field in data, f"Missing '{field}' in credit card constants"

        context.data["credit_card_constants"] = {
            "min_credit_limit": float(data["minCreditLimit"]),
            "max_credit_limit": float(data["maxCreditLimit"]),
            "lien_factor": float(data["lienFactor"]),
        }

    optional_fields = [
        "annualFee",
        "annualPercentageRate",
        "latePaymentFee",
        "cashAdvanceFee",
        "atmWithdrawalFee",
        "fedOnFeesPercent",
    ]

    for field in optional_fields:
        if field in data:
            context.data["credit_card_constants"][field] = data[field]


@Step("User ([^']*) view the credit card PIN for ([^']*)")
def view_credit_card_pin(context, uid: str,card_tag):
    request = context.request

    card_id = ah.get_card_id(context, uid, card_tag)

    headers = ah.get_user_header(context, uid)

    headers["x-final-user-authorisation-token"] = context.data["users"][uid][
        "user_authorisation_token"
    ]

    response = request.hugosave_get_request(
        path=ah.credit_card_urls["show_card_pin"].replace("{card-id}", card_id),
        headers=headers,
    )

    if not check_status_distribute(response, 200):
        raise ValueError(f"Expected 200 for SHOW_CARD_PIN, received: {response}")
    if "data" not in response:
        raise KeyError(f"Missing data in response: {response}")

    data_keys = response["data"]
    assert "encryptedPin" in data_keys and "key" in data_keys, (
        f"Expected encryptedPin and key in response, received: {data_keys}"
    )


@Step("Check the available credits for user ([^']*) and available credit should be ([^']*)")
def check_available_credit(context, uid, checks):
    request = context.request

    credit_account_id = ah.get_credit_account_id(context, uid)

    amount = 0.0
    precision = ""
    amount_checks_list = checks.split(" ")

    for item in amount_checks_list:
        try:
            amount = float(item)
        except ValueError:
            if item == "approx" or item == "exact":
                precision = item

    @retry(AssertionError, tries=40, delay=20, logger=None)
    def retry_for_available_credit():
        response = request.hugosave_get_request(
            path=ah.cms_urls["balance"].replace("{account-id}", credit_account_id),
            headers=ah.get_user_header(context, uid),
        )

        if check_status_distribute(response, 200):
            available_credit_balance = response["data"]["availableCredit"]

            if precision == "approx":
                assert amount - 1 <= available_credit_balance <= amount + 1, \
                    f"Approx check failed! Expected ~{amount}, but got {available_credit_balance}"
            elif precision == "exact":
                assert available_credit_balance == amount, \
                    f"Exact check failed! Expected {amount}, but got {available_credit_balance}"
            else:
                assert available_credit_balance == amount, \
                    f"Comparison failed! Got {available_credit_balance}"

    retry_for_available_credit()


@Step(
    "User ([^']*) verified approved limit and it should be ([^']*)"
)
def verify_approved_limit(context, uid: str, checks: str):

    request = context.request

    amount, precision = ah.parse_amount_and_precision(checks)

    @retry(AssertionError, tries=20, delay=20, logger=None)
    def retry_for_approved_limit():

        response = request.hugosave_get_request(
            path=ah.user_profile_urls["credit-account-list"],
            headers=ah.get_user_header(context, uid),
        )

        if check_status_distribute(response, 200):
            assert "data" in response and "creditAccounts" in response["data"], (
                f"Missing creditAccounts in response: {response}"
            )
        credit_accounts = response["data"]["creditAccounts"]

        credit_account_id = ah.get_credit_account_id(context, uid)
        approved_limit = None
        for account in credit_accounts:
            if account.get("creditAccountId") == credit_account_id:
                approved_limit = float(account.get("approvedLimit"))
                break
        assert approved_limit is not None, "Matching credit account not found"

        if precision == "approx":
            assert amount - 1 <= approved_limit <= amount + 1, (
                f"Approx check failed! Expected ~{amount}, got {approved_limit}"
            )
        elif precision == "exact":
            assert approved_limit == amount, (
                f"Exact check failed! Expected {amount}, got {approved_limit}"
            )
        else:
            assert approved_limit == amount, (
                f"Comparison failed! Expected {amount}, got {approved_limit}"
            )

    retry_for_approved_limit()


@Step("User ([^']*) get channel limit history for ([^']*) and expect status code ([^']*)")
def get_channel_limit_history(context, uid: str, card_tag,expected_status_code: str):
    request = context.request
    card_id=ah.get_card_id(context,uid,card_tag)

    limit_dto_list = DataClassParser.parse_rows(
        context.table, GetChannelLimitHistoryDTO
    )
    for limit_dto in limit_dto_list:
        requested_limit_name = limit_dto.get_credit_limit_history()

    resolved_limit_id=""
    user_cards = context.data["users"][uid]["cards"]
    for channel in user_cards["cardTxnChannelDetails"]["channelDetails"]:
        if channel["channel"] == requested_limit_name:
            resolved_limit_id = channel["cardLimitDetails"]["limitId"]


    response = request.hugosave_get_request(
        path=ah.card_urls["get_limit_history"].replace("{card-id}", card_id),
        params={"limit-id": resolved_limit_id},
        headers=ah.get_user_header(context, uid),
    )

    if check_status_distribute(response, expected_status_code):
        assert "data" in response and "limitHistory" in response["data"], (
            f"Missing limitHistory in response: {response}"
        )

    credit_accounts = context.data["users"][uid].get("credit_accounts", [])

    for account in credit_accounts:
        account["limitHistory"] = response["data"]["limitHistory"]


@Step("User ([^']*) update credit limit and expect a status code of ([^']*)")
def update_credit_limit(context, uid, expected_status_code):
    request = context.request

    limit_dto_list = DataClassParser.parse_rows(
        context.table, UpdateCreditLimitDTO
    )
    for limit_dto in limit_dto_list:
        final_requested_limit = limit_dto.get_updated_credit_limit()


    account_id = ah.get_credit_account_id(context, uid)

    payload = {
        "approvedLimit": final_requested_limit
    }

    headers = ah.get_user_header(context, uid)
    headers["x-final-user-authorisation-token"] = context.data["users"][uid][
        "user_authorisation_token"
    ]

    response = request.hugosave_put_request(
        path=ah.credit_card_urls["update_credit_limit"].replace(
            "{account-id}", account_id
        ),
        data=payload,
        headers=headers,
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )


@Step("User ([^']*) get cash advance limit for credit account expect a status code of ([^']*)")
def get_cash_advance_limit(context, uid, expected_status_code):
    request = context.request

    account_id = ah.get_credit_account_id(context, uid)

    response = request.hugosave_get_request(
        path=ah.credit_card_urls["get_cash_advance_limit"].replace(
            "{account-id}", account_id
        ),
        headers=ah.get_user_header(context, uid),
    )

    if check_status_distribute(response, expected_status_code):
        assert "data" in response, f"Missing data in response: {response}"

    context.data["users"][uid]["cash_advance_limit"] = response["data"]


@Step("User ([^']*) request cash advance for credit account and expect a status code of ([^']*)")
def request_cash_advance(context, uid, expected_status_code):
    request = context.request

    requested_amount=None
    limit_dto_list = DataClassParser.parse_rows(
        context.table, CashAdvanceRequestDTO
    )
    for limit_dto in limit_dto_list:
        requested_amount = limit_dto.get_cash_advance_amount()


    account_id = ah.get_credit_account_id(context, uid)

    default_cash_wallet_id = None
    wallets = context.data["users"][uid]["user_cash_wallets"]["userCashWallets"]
    for wallet in wallets:
        if wallet.get("productCode") == "CASH_WALLET_CURRENT":
            default_cash_wallet_id = wallet.get("cashWalletId")
            break
    assert default_cash_wallet_id, "CASH_WALLET_CURRENT wallet not found"

    payload = {
        "amount": requested_amount,
        "cashWalletId": default_cash_wallet_id,
    }

    headers = ah.get_user_header(context, uid)
    headers["x-final-user-authorisation-token"] = context.data["users"][uid][
        "user_authorisation_token"
    ]

    response = request.hugosave_post_request(
        path=ah.credit_card_urls["request_cash_advance"].replace(
            "{account-id}", account_id
        ),
        data=payload,
        headers=headers,
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )


@Step("User ([^']*) generate credit account bill and expect status code ([^']*)")
def generate_credit_account_bill(context, uid, expected_status_code):
    request = context.request

    account_id = ah.get_credit_account_id(context, uid)

    response = request.hugosave_post_request(
        path=ah.dev_urls["generate_credit_bills"],
        data={
            "creditAccountId": account_id
        },
        headers=ah.get_user_header(context, uid),
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )

    context.data["users"][uid]["generated_credit_bill_response"] = response


@Step("User ([^']*) get the credit account bills and expect status code ([^']*)")
def get_credit_account_bills(context, uid, expected_status_code):
    request = context.request

    account_id = ah.get_credit_account_id(context, uid)

    response = request.hugosave_get_request(
        path=ah.credit_card_urls["get_credit_account_bills"].replace(
            "{account-id}", account_id
        ),
        headers=ah.get_user_header(context, uid),
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )

    assert "data" in response, f"Missing data in response: {response}"

    context.data["users"][uid]["credit_account_bills"] = response["data"]


@Step("User ([^']*) get the latest credit account bill and expect status code ([^']*) and bill present as ([^']*)")
def get_latest_credit_account_bill(context, uid, expected_status_code, expected_bill_present):
    request = context.request

    account_id = ah.get_credit_account_id(context, uid)

    response = request.hugosave_get_request(
        path=ah.credit_card_urls["get_credit_account_latest_bill"].replace(
            "{account-id}", account_id
        ),
        headers=ah.get_user_header(context, uid),
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )

    bill_data = response.get("data")
    assert bill_data is not None, f"Missing data in response: {response}"

    expected_bill_present = expected_bill_present.lower() == "true"

    assert bill_data.get("billPresent") is expected_bill_present, (
        f"Expected billPresent {expected_bill_present}, received: {bill_data}"
    )

    context.data["users"][uid]["latest_credit_account_bill"] = bill_data


@Step("User ([^']*) pay credit account bill with amount ([^']*) and expect status code ([^']*) and intent status as ([^']*)")
def pay_credit_account_bill_with_amount(context, uid, amount, expected_status_code, expected_intent_status):
    request = context.request

    user_data = context.data["users"][uid]

    credit_account_id = ah.get_credit_account_id(context, uid)

    cash_wallet_id = None
    wallets = context.data["users"][uid]["user_cash_wallets"]["userCashWallets"]
    for wallet in wallets:
        if wallet.get("productCode") == "CASH_WALLET_CURRENT":
            cash_wallet_id = wallet.get("cashWalletId")
            break
    assert cash_wallet_id, "CASH_WALLET_CURRENT wallet not found"


    payload = {
        "amount": float(amount),
        "cashWalletId": cash_wallet_id
    }

    response = request.hugosave_post_request(
        path=ah.credit_card_urls["pay_credit_account_bill"].replace(
            "{account-id}", credit_account_id
        ),
        headers=ah.get_user_header(context, uid),
        data=payload,
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )

    response_data = response.get("data")
    assert response_data is not None, f"Missing data in response: {response}"

    assert response_data.get("status") == expected_intent_status, (
        f"Expected intent status {expected_intent_status}, received: {response_data}"
    )

    assert response_data.get("intentId"), (
        f"Missing intentId in response: {response_data}"
    )


@Step("User ([^']*) close credit account using settlement source ([^']*) and expect status code ([^']*)")
def close_credit_account(context, uid, settlement_source, expected_status_code):
    request = context.request

    credit_account_id = ah.get_credit_account_id(context, uid)

    headers = ah.get_user_header(context, uid)
    if "user_authorisation_token" in context.data["users"][uid]:
        headers["x-final-user-authorisation-token"] = context.data["users"][
            uid
        ]["user_authorisation_token"]

    response = request.hugosave_delete_request(
        path=ah.credit_card_urls["close_credit_account"].replace(
            "{account-id}", credit_account_id
        ),
        params={
            "settlement-source": settlement_source
        },
        headers=headers,
    )

    assert check_status_distribute(response, expected_status_code), (
        f"Expected {expected_status_code}, received: {response}"
    )


@Step("User ([^']*) verify credit account is closed")
def verify_credit_account_closed(context, uid: str):

    request = context.request

    previous_accounts = context.data["users"][uid].get("credit_accounts", [])

    credit_account_id = None
    for account in previous_accounts:
        credit_account_id = account.get("creditAccountId")
        if credit_account_id:
            break
    assert credit_account_id, "Unable to resolve creditAccountId from stored credit accounts"

    @retry(AssertionError, tries=20, delay=20, logger=None)
    def retry_verify_closure():

        response = request.hugosave_get_request(
            path=ah.user_profile_urls["credit-account-list"],
            headers=ah.get_user_header(context, uid),
        )

        assert check_status_distribute(response, 200), (
            f"Failed to fetch credit accounts. Response: {response}"
        )

        accounts = response["data"].get("creditAccounts", [])

        if not accounts:
            return

        for account in accounts:
            if account["creditAccountId"] == credit_account_id:
                status = account.get("accountStatus")
                assert status == "ACCOUNT_CLOSED", (
                    f"Credit account not closed yet. Current status: {status}"
                )
                return
        return

    retry_verify_closure()


@Step("User ([^']*) fetch credit account list")
def fetch_credit_account_list(context, uid):
    request = context.request

    @retry(AssertionError, delay=20, tries=20, logger=None)
    def wait_for_credit_accounts():
        response = request.hugosave_get_request(
            path=ah.user_profile_urls["credit-account-list"],
            headers=ah.get_user_header(context, uid),
        )

        assert check_status_distribute(response, 200), (
            f"Failed to fetch credit accounts. Response: {response}"
        )

        assert (
                "data" in response and "creditAccounts" in response["data"] and len(response["data"]["creditAccounts"]) > 0
        ), f"Response: {response}"

        context.data["users"][uid]["credit_accounts"] = response["data"]["creditAccounts"]

    wait_for_credit_accounts()


@Step("User ([^']*) store credit card replacement details for ([^']*)")
def store_credit_card_replacement_snapshot(context, uid: str, card_tag):

    user_data = context.data["users"][uid]

    credit_account_id = ah.get_credit_account_id(context, uid)

    credit_accounts = user_data.get("credit_accounts", [])
    assert credit_accounts, "No credit accounts found in user data"

    approved_limit = None
    for account in credit_accounts:
        if account.get("creditAccountId") == credit_account_id:
            approved_limit = float(account.get("approvedLimit"))
            break
    assert approved_limit is not None, f"Approved limit not found for credit account {credit_account_id}"

    balance_data = user_data.get("credit_account_balance")
    assert balance_data, "Credit account balance not fetched before snapshot"

    snapshot = {
        "old_card_id": user_data[card_tag]["card_id"],
        "old_card_account_id": user_data[card_tag]["cardAccountId"],
        "creditAccountId": credit_account_id,
        "approvedLimit": approved_limit,
        "availableCredit": float(balance_data["availableCredit"]),
        "settledAmount": float(balance_data["settledAmount"]),
        "unsettledAmount": float(balance_data["unsettledAmount"]),
    }

    context.data["users"][uid]["replace_snapshot"] = snapshot


@Step("User ([^']*) replace ([^']*) and expect a card status of ([^']*)")
def replace_card(context, uid: str, card_tag: str,  expected_status: str):

    request = context.request

    old_card_id = ah.get_card_id(context,uid,card_tag)

    context.data["users"][uid]["old_card_id"] = old_card_id

    headers = ah.get_user_header(context, uid)
    headers["x-final-user-authorisation-token"] = context.data["users"][uid]["user_authorisation_token"]

    response = request.hugosave_post_request(
        path=ah.card_urls["replace_card"].replace("{card-id}", old_card_id),
        headers=headers,
        data={}
    )

    # assert check_status_distribute(response, 200), f"Replace failed: {response}"
    if check_status_distribute(response, 200):
        assert response["headers"].get("statusCode") == "200", (
            f"Replace failed: {response}"
        )

    assert response["data"]["cardStatus"] == expected_status, (
        f"Expected {expected_status}, got {response['data']['cardStatus']}"
    )

    context.data["users"][uid]["replaced_credit_card"] = {
        "cardId": response["data"]["cardId"],
        "cardAccountId": response["data"]["cardAccountId"],
        "cardStatus": response["data"]["cardStatus"],
        "cardType": response["data"]["cardType"],
        "category": response["data"]["category"],
        "nameOnCard": response["data"].get("nameOnCard"),
    }


@Step("User ([^']*) verify credit account details after replacement")
def verify_credit_account_integrity(context, uid: str):

    request=context.request
    user_data = context.data["users"][uid]
    snapshot = user_data["replace_snapshot"]

    credit_accounts = user_data.get("credit_accounts", [])
    for account in credit_accounts:
        credit_account = account
        break

    balance = user_data["credit_account_balance"]
    new_card = user_data["replaced_credit_card"]

    # 700 is charge and 15% is tax(Fixed amount)
    tax_on_replacement = 700 + (0.15 * 700)

    assert new_card["cardId"] != snapshot["old_card_id"], \
        "Card ID did not change after replacement"

    assert credit_account["creditAccountId"] == snapshot["creditAccountId"], \
        "Credit Account ID changed after replacement"

    assert float(credit_account["approvedLimit"]) == snapshot["approvedLimit"], \
        "Approved limit changed after replacement"

    @retry(AssertionError, tries=20, delay=15, logger=None)
    def retry_balance_verification():

        credit_account_id = ah.get_credit_account_id(context, uid)

        response = request.hugosave_get_request(
            path=ah.cms_urls["balance"].replace("{account-id}", credit_account_id),
            headers=ah.get_user_header(context, uid),
        )

        assert check_status_distribute(response, 200), \
            f"Failed to fetch balance: {response}"

        balance = response["data"]
        available_credit_after_rep = float(snapshot["availableCredit"]) - float(tax_on_replacement)
        assert float(balance["availableCredit"]) == float(available_credit_after_rep), \
            "Available credit changed after replacement"

        settled_amount_after_rep=float(snapshot["settledAmount"])+ float(tax_on_replacement)
        assert float(balance["settledAmount"]) == float(settled_amount_after_rep), \
            "Settled amount changed after replacement"

        assert float(balance["unsettledAmount"]) == snapshot["unsettledAmount"], \
            "Unsettled amount changed after replacement"

    retry_balance_verification()


@Step("User ([^']*) check old card status is ([^']*)")
def check_old_card_status(context, uid, old_card_status):
    request = context.request
    card_id = context.data["users"][uid]["old_card_id"]

    response = request.hugosave_get_request(
        path=ah.card_urls["card_details"].replace("{card-id}", card_id),
        headers=ah.get_user_header(context, uid),
    )
    if check_status_distribute(response, 200):
        assert (
                response["data"]["cardStatus"] == old_card_status
        ), f"Expected Card status: {old_card_status}\nActual Card status: {response['data']['cardStatus']}"


@Step("User ([^']*) fetch credit account balance")
def fetch_credit_account_list(context, uid):
    request = context.request
    credit_account_id = ah.get_credit_account_id(context, uid)

    response = request.hugosave_get_request(
        path=ah.cms_urls["balance"].replace("{account-id}", credit_account_id),
        headers=ah.get_user_header(context, uid),
    )

    if check_status_distribute(response, 200):
        context.data["users"][uid]["credit_account_balance"] = response["data"]


