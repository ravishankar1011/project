"""Exporting cleaned datasets, forecasts, and reports (Module 1 'Export results' feature)."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from greenpulse.logging_config import get_logger

logger = get_logger("export.exporter")

REPORTS_DIR = Path(__file__).resolve().parents[3] / "outputs" / "reports"
PROCESSED_DIR = Path(__file__).resolve().parents[3] / "data" / "processed"


def export_dataframe(df: pd.DataFrame, filename: str, fmt: str = "csv", processed: bool = True) -> Path:
    target_dir = PROCESSED_DIR if processed else REPORTS_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    path = target_dir / f"{filename}.{fmt}"

    if fmt == "csv":
        df.to_csv(path)
    elif fmt == "json":
        df.reset_index().to_json(path, orient="records", date_format="iso", indent=2)
    else:
        raise ValueError(f"Unsupported export format '{fmt}'. Choose 'csv' or 'json'.")

    logger.info("Exported %d rows to %s", len(df), path)
    return path


def series_to_json_dict(series: pd.Series) -> dict:
    """Convert a (possibly DatetimeIndex-keyed) Series to a JSON-safe dict with string keys."""
    return {str(k): v for k, v in series.items()}


def export_report(report: dict, filename: str) -> Path:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    path = REPORTS_DIR / f"{filename}.json"
    with open(path, "w") as f:
        json.dump(report, f, indent=2, default=str)
    logger.info("Exported report to %s", path)
    return path
