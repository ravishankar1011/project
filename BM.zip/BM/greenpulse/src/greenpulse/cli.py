"""GreenPulse command-line application (Module 1).

Usage examples:
    python main.py generate-data
    python main.py list-datasets
    python main.py stats prices
    python main.py clean prices --column electricity_price --method interpolate --export
    python main.py analyze solar --column solar_generation_mwh --resample W --rolling 7 --trend
    python main.py decompose solar --column solar_generation_mwh --period 365
    python main.py plot wind --column wind_generation_mwh --type trend
    python main.py forecast-price --column electricity_price --model random_forest --horizon 14
    python main.py forecast-weather --column wind_speed_ms --model random_forest --horizon 7 --estimate-energy
"""
from __future__ import annotations

import argparse
import sys

import pandas as pd
from tabulate import tabulate

from greenpulse.analytics import stats as stats_module
from greenpulse.analytics import timeseries
from greenpulse.analytics import visualization as viz
from greenpulse.data.cleaner import DataCleaner, MISSING_METHODS
from greenpulse.data.generator import generate_all
from greenpulse.data.loader import DatasetLoader
from greenpulse.exceptions import GreenPulseError
from greenpulse.export.exporter import export_dataframe, export_report, series_to_json_dict
from greenpulse.forecasting.price_forecaster import PriceForecaster, MODEL_REGISTRY as PRICE_MODELS
from greenpulse.forecasting.weather_forecaster import WeatherForecaster, estimate_wind_energy, MODEL_REGISTRY as WEATHER_MODELS
from greenpulse.logging_config import get_logger, setup_logging

logger = get_logger("cli")


class GreenPulseCLI:
    """Encapsulates all CLI subcommands as methods so state (e.g. the loader) is shared cleanly."""

    def __init__(self):
        self.loader = DatasetLoader()

    # ---- Module 1 ----------------------------------------------------
    def cmd_generate_data(self, args) -> int:
        written = generate_all(force=args.force)
        if written:
            print(f"Generated datasets: {', '.join(written)}")
        else:
            print("All datasets already exist. Use --force to regenerate.")
        return 0

    def cmd_list_datasets(self, args) -> int:
        print(tabulate({"dataset": self.loader.available_datasets()}, headers="keys", tablefmt="simple"))
        return 0

    def cmd_stats(self, args) -> int:
        df = self.loader.load(args.dataset)
        summary = stats_module.summarize(df)
        print(tabulate(summary, headers="keys", tablefmt="github"))
        if args.correlation:
            print("\nCorrelation matrix:")
            print(tabulate(stats_module.correlation(df), headers="keys", tablefmt="github"))
        return 0

    def cmd_clean(self, args) -> int:
        df = self.loader.load(args.dataset)
        cleaner = DataCleaner(df)

        report = cleaner.missing_value_report()
        print("Missing values before cleaning:")
        print(tabulate(report.to_frame("missing_count"), headers="keys", tablefmt="github") if not report.empty else "  none")

        columns = [args.column] if args.column else None
        cleaned = cleaner.handle_missing(method=args.method, columns=columns)
        if args.clip_outliers:
            cleaned = cleaner.clip_outliers(columns=columns)

        print(f"\nCleaned dataset using method='{args.method}'"
              f"{' + outlier clipping' if args.clip_outliers else ''}. Remaining NaNs: {int(cleaned.isna().sum().sum())}")

        if args.export:
            path = export_dataframe(cleaned, f"{args.dataset}_cleaned")
            print(f"Exported cleaned dataset -> {path}")
        return 0

    # ---- Module 2 ----------------------------------------------------
    def cmd_analyze(self, args) -> int:
        df = self.loader.load(args.dataset)
        series = self._select_column(df, args.column)

        if args.resample:
            resampled = timeseries.resample(df, freq=args.resample)
            print(f"Resampled ({timeseries.RESAMPLE_FREQS[args.resample]}):")
            print(tabulate(resampled.tail(10), headers="keys", tablefmt="github"))

        if args.rolling:
            rolled = timeseries.rolling_average(df, window=args.rolling, columns=[args.column])
            print(f"\n{args.rolling}-day rolling average (last 10):")
            print(tabulate(rolled.tail(10), headers="keys", tablefmt="github"))

        if args.trend:
            trend = timeseries.trend_analysis(series)
            print("\nTrend analysis:")
            print(tabulate(trend.items(), tablefmt="github"))

        return 0

    def cmd_decompose(self, args) -> int:
        df = self.loader.load(args.dataset)
        series = self._select_column(df, args.column)
        result = timeseries.decompose(series, period=args.period, model=args.model)
        path = viz.plot_seasonal_decomposition(
            result, title=f"Seasonal decomposition: {args.column}", filename=f"{args.dataset}_{args.column}_decompose.png"
        )
        print(f"Trend/seasonal/residual decomposition saved -> {path}")
        return 0

    def cmd_plot(self, args) -> int:
        df = self.loader.load(args.dataset)
        series = self._select_column(df, args.column)

        if args.type == "line":
            path = viz.plot_line(df, [args.column], title=f"{args.dataset}: {args.column}",
                                  filename=f"{args.dataset}_{args.column}_line.png")
        elif args.type == "trend":
            path = viz.plot_trend(series, rolling_window=args.rolling, title=f"{args.dataset}: {args.column} trend",
                                   filename=f"{args.dataset}_{args.column}_trend.png")
        else:
            raise GreenPulseError(f"Unknown plot type '{args.type}'.")

        print(f"Plot saved -> {path}")
        return 0

    # ---- Module 3 ----------------------------------------------------
    def cmd_forecast_price(self, args) -> int:
        df = self.loader.load(args.dataset)
        series = self._select_column(df, args.column)

        forecaster = PriceForecaster(model_name=args.model)
        metrics = forecaster.fit(series, test_size=args.test_size)
        forecast = forecaster.forecast(horizon=args.horizon)

        print(f"Model: {args.model} | Holdout metrics: {metrics}")
        print(f"\nForecast for next {args.horizon} day(s):")
        print(tabulate(forecast.to_frame("predicted_price"), headers="keys", tablefmt="github"))

        if args.plot:
            path = viz.plot_forecast(series, forecast, title=f"{args.column} price forecast ({args.model})",
                                      filename=f"{args.dataset}_{args.column}_price_forecast.png")
            print(f"Forecast plot saved -> {path}")

        if args.export:
            report = {"model": args.model, "metrics": metrics, "forecast": series_to_json_dict(forecast)}
            path = export_report(report, f"{args.dataset}_{args.column}_price_forecast")
            print(f"Forecast report exported -> {path}")
        return 0

    # ---- Module 4 ----------------------------------------------------
    def cmd_forecast_weather(self, args) -> int:
        df = self.loader.load(args.dataset)
        series = self._select_column(df, args.column)

        forecaster = WeatherForecaster(model_name=args.model)
        metrics = forecaster.fit(series, test_size=args.test_size)
        forecast = forecaster.forecast(horizon=args.horizon)

        print(f"Model: {args.model} | Holdout metrics: {metrics}")
        print(f"\nWeather forecast for next {args.horizon} day(s) ({args.column}):")
        print(tabulate(forecast.to_frame("predicted_value"), headers="keys", tablefmt="github"))

        energy_estimate = None
        if args.estimate_energy:
            if args.column != "wind_speed_ms":
                print("\nWarning: --estimate-energy assumes the forecasted column is wind speed (m/s).")
            energy_estimate = estimate_wind_energy(forecast)
            print("\nEstimated wind energy generation (MWh):")
            print(tabulate(energy_estimate.to_frame(), headers="keys", tablefmt="github"))

        if args.plot:
            path = viz.plot_forecast(series, forecast, title=f"{args.column} weather forecast ({args.model})",
                                      filename=f"{args.dataset}_{args.column}_weather_forecast.png")
            print(f"Forecast plot saved -> {path}")

        if args.export:
            report = {"model": args.model, "metrics": metrics, "forecast": series_to_json_dict(forecast)}
            if energy_estimate is not None:
                report["estimated_wind_energy_mwh"] = series_to_json_dict(energy_estimate)
            path = export_report(report, f"{args.dataset}_{args.column}_weather_forecast")
            print(f"Forecast report exported -> {path}")
        return 0

    # ---- Module 1 (export) -------------------------------------------
    def cmd_export(self, args) -> int:
        df = self.loader.load(args.dataset)
        path = export_dataframe(df, args.dataset, fmt=args.format, processed=True)
        print(f"Exported -> {path}")
        return 0

    @staticmethod
    def _select_column(df: pd.DataFrame, column: str) -> pd.Series:
        if column not in df.columns:
            raise GreenPulseError(f"Column '{column}' not found. Available columns: {list(df.columns)}")
        return df[column]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="greenpulse", description="GreenPulse Renewable Energy Analytics Platform")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("generate-data", help="Generate synthetic renewable-energy datasets").add_argument(
        "--force", action="store_true", help="Regenerate even if files already exist")

    sub.add_parser("list-datasets", help="List available named datasets")

    p_stats = sub.add_parser("stats", help="View descriptive statistics for a dataset")
    p_stats.add_argument("dataset", help="Named dataset (solar/wind/demand/prices/weather) or file path")
    p_stats.add_argument("--correlation", action="store_true", help="Also show the correlation matrix")

    p_clean = sub.add_parser("clean", help="Clean missing values (and optionally outliers)")
    p_clean.add_argument("dataset")
    p_clean.add_argument("--column", help="Restrict cleaning to a single column")
    p_clean.add_argument("--method", choices=MISSING_METHODS, default="interpolate")
    p_clean.add_argument("--clip-outliers", action="store_true", help="Also detect and clip statistical outliers")
    p_clean.add_argument("--export", action="store_true", help="Export the cleaned dataset to data/processed/")

    p_analyze = sub.add_parser("analyze", help="Resampling, rolling averages, trend analysis")
    p_analyze.add_argument("dataset")
    p_analyze.add_argument("--column", required=True)
    p_analyze.add_argument("--resample", choices=list(timeseries.RESAMPLE_FREQS), help="Resample frequency")
    p_analyze.add_argument("--rolling", type=int, help="Rolling average window (days)")
    p_analyze.add_argument("--trend", action="store_true", help="Compute linear trend summary")

    p_decompose = sub.add_parser("decompose", help="Seasonal decomposition (trend/seasonal/residual)")
    p_decompose.add_argument("dataset")
    p_decompose.add_argument("--column", required=True)
    p_decompose.add_argument("--period", type=int, default=365, help="Seasonal period in days (default 365)")
    p_decompose.add_argument("--model", choices=["additive", "multiplicative"], default="additive")

    p_plot = sub.add_parser("plot", help="Plot graphs for a dataset column")
    p_plot.add_argument("dataset")
    p_plot.add_argument("--column", required=True)
    p_plot.add_argument("--type", choices=["line", "trend"], default="line")
    p_plot.add_argument("--rolling", type=int, default=7, help="Rolling window for --type trend")

    p_price = sub.add_parser("forecast-price", help="Forecast green energy prices")
    p_price.add_argument("--dataset", default="prices")
    p_price.add_argument("--column", default="electricity_price")
    p_price.add_argument("--model", choices=list(PRICE_MODELS), default="random_forest")
    p_price.add_argument("--horizon", type=int, default=7, help="Days ahead to forecast")
    p_price.add_argument("--test-size", type=float, default=0.2)
    p_price.add_argument("--plot", action="store_true")
    p_price.add_argument("--export", action="store_true")

    p_weather = sub.add_parser("forecast-weather", help="Forecast weather for windmills")
    p_weather.add_argument("--dataset", default="weather")
    p_weather.add_argument("--column", default="wind_speed_ms")
    p_weather.add_argument("--model", choices=list(WEATHER_MODELS), default="random_forest")
    p_weather.add_argument("--horizon", type=int, default=7)
    p_weather.add_argument("--test-size", type=float, default=0.2)
    p_weather.add_argument("--estimate-energy", action="store_true", help="Estimate wind-energy output from forecasted wind speed")
    p_weather.add_argument("--plot", action="store_true")
    p_weather.add_argument("--export", action="store_true")

    p_export = sub.add_parser("export", help="Export a raw/named dataset to data/processed/")
    p_export.add_argument("dataset")
    p_export.add_argument("--format", choices=["csv", "json"], default="csv")

    return parser


COMMAND_HANDLERS = {
    "generate-data": "cmd_generate_data",
    "list-datasets": "cmd_list_datasets",
    "stats": "cmd_stats",
    "clean": "cmd_clean",
    "analyze": "cmd_analyze",
    "decompose": "cmd_decompose",
    "plot": "cmd_plot",
    "forecast-price": "cmd_forecast_price",
    "forecast-weather": "cmd_forecast_weather",
    "export": "cmd_export",
}


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    setup_logging(verbose=args.verbose)

    cli = GreenPulseCLI()
    handler = getattr(cli, COMMAND_HANDLERS[args.command])

    try:
        return handler(args)
    except GreenPulseError as exc:
        logger.error(str(exc))
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except Exception:
        logger.exception("Unexpected error while running command '%s'", args.command)
        print(f"Unexpected error: see logs/greenpulse.log for details", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
