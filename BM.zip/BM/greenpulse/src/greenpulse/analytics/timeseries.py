"""Time-series analytics: resampling, rolling averages, trend & seasonal decomposition (Module 2)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import seasonal_decompose, DecomposeResult

from greenpulse.exceptions import InsufficientDataError
from greenpulse.logging_config import get_logger

logger = get_logger("analytics.timeseries")

RESAMPLE_FREQS = {"D": "Daily", "W": "Weekly", "M": "Monthly", "Q": "Quarterly", "Y": "Yearly"}


def resample(df: pd.DataFrame, freq: str = "W", agg: str = "mean") -> pd.DataFrame:
    if freq not in RESAMPLE_FREQS:
        raise ValueError(f"Unsupported frequency '{freq}'. Choose from {list(RESAMPLE_FREQS)}.")
    resampled = df.select_dtypes("number").resample(freq).agg(agg)
    logger.info("Resampled %d rows -> %d rows at %s frequency (%s)", len(df), len(resampled), freq, agg)
    return resampled


def rolling_average(df: pd.DataFrame, window: int = 7, columns: list[str] | None = None) -> pd.DataFrame:
    cols = columns or df.select_dtypes("number").columns.tolist()
    rolled = df[cols].rolling(window=window, min_periods=1).mean()
    rolled.columns = [f"{c}_rolling_{window}" for c in rolled.columns]
    return rolled


def trend_analysis(series: pd.Series, window: int = 30) -> dict:
    """Simple linear-trend summary: slope per day and overall direction."""
    clean = series.dropna()
    if len(clean) < 2:
        raise InsufficientDataError("Need at least 2 non-null points for trend analysis.")
    x = (clean.index - clean.index[0]).days.values.astype(float)
    y = clean.values.astype(float)
    slope, intercept = np.polyfit(x, y, 1)
    direction = "increasing" if slope > 0 else "decreasing" if slope < 0 else "flat"
    return {
        "slope_per_day": round(float(slope), 5),
        "direction": direction,
        "start_value": round(float(y[0]), 3),
        "end_value": round(float(y[-1]), 3),
        "pct_change": round(float((y[-1] - y[0]) / y[0] * 100), 2) if y[0] != 0 else None,
        "rolling_mean_window": window,
    }


def decompose(series: pd.Series, period: int = 365, model: str = "additive") -> DecomposeResult:
    clean = series.asfreq("D").interpolate().ffill().bfill()
    if len(clean) < period * 2:
        raise InsufficientDataError(
            f"Need at least {period * 2} data points for seasonal decomposition with period={period}, got {len(clean)}."
        )
    logger.info("Running %s seasonal decomposition (period=%d) on %d points", model, period, len(clean))
    return seasonal_decompose(clean, model=model, period=period)
