"""Plotting utilities (Module 1 'Plot graphs' feature). Saves PNGs, no display required."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # headless-safe backend, must be set before pyplot import
import matplotlib.pyplot as plt
import pandas as pd

from greenpulse.logging_config import get_logger

logger = get_logger("analytics.visualization")

PLOTS_DIR = Path(__file__).resolve().parents[3] / "outputs" / "plots"


def _save(fig, filename: str) -> Path:
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    path = PLOTS_DIR / filename
    fig.savefig(path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved plot to %s", path)
    return path


def plot_line(df: pd.DataFrame, columns: list[str], title: str, filename: str) -> Path:
    fig, ax = plt.subplots(figsize=(11, 5))
    for col in columns:
        ax.plot(df.index, df[col], label=col, linewidth=1.2)
    ax.set_title(title)
    ax.set_xlabel("Date")
    ax.legend()
    ax.grid(alpha=0.3)
    return _save(fig, filename)


def plot_trend(series: pd.Series, rolling_window: int, title: str, filename: str) -> Path:
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(series.index, series.values, label=series.name or "value", alpha=0.4, linewidth=1)
    ax.plot(series.index, series.rolling(rolling_window, min_periods=1).mean(),
             label=f"{rolling_window}-day rolling mean", linewidth=2, color="darkorange")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    return _save(fig, filename)


def plot_seasonal_decomposition(decomposition, title: str, filename: str) -> Path:
    fig = decomposition.plot()
    fig.set_size_inches(11, 8)
    fig.suptitle(title, y=1.02)
    return _save(fig, filename)


def plot_forecast(history: pd.Series, forecast: pd.Series, title: str, filename: str) -> Path:
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(history.index, history.values, label="Historical", color="steelblue")
    ax.plot(forecast.index, forecast.values, label="Forecast", color="crimson", linestyle="--", marker="o", markersize=3)
    ax.axvline(history.index[-1], color="gray", linestyle=":", alpha=0.7)
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    return _save(fig, filename)
