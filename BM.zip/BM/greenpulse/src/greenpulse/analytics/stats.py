"""Descriptive statistics (Module 1 'View statistics' feature)."""
from __future__ import annotations

import pandas as pd

from greenpulse.logging_config import get_logger

logger = get_logger("analytics.stats")


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    """Return describe() plus missing-value counts and % for every numeric column."""
    numeric = df.select_dtypes("number")
    desc = numeric.describe().T
    desc["missing"] = numeric.isna().sum()
    desc["missing_pct"] = (numeric.isna().mean() * 100).round(2)
    date_range = f"{df.index.min().date()} to {df.index.max().date()}" if isinstance(df.index, pd.DatetimeIndex) else "n/a"
    logger.info("Dataset covers %s (%d rows)", date_range, len(df))
    return desc.round(3)


def correlation(df: pd.DataFrame) -> pd.DataFrame:
    return df.select_dtypes("number").corr().round(3)
