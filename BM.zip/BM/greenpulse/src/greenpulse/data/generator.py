"""Synthetic renewable-energy dataset generator.

Produces realistic-looking daily time series (with trend, annual/weekly
seasonality, noise, injected missing values and outliers) so the rest of
the platform can be exercised end-to-end without needing real utility data.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from greenpulse.logging_config import get_logger

logger = get_logger("data.generator")

RAW_DIR = Path(__file__).resolve().parents[3] / "data" / "raw"

START_DATE = "2022-01-01"
NUM_DAYS = 1095  # 3 years of daily data


def _date_index(num_days: int = NUM_DAYS) -> pd.DatetimeIndex:
    return pd.date_range(start=START_DATE, periods=num_days, freq="D")


def _inject_missing(series: pd.Series, rng: np.random.Generator, frac: float = 0.03) -> pd.Series:
    series = series.copy()
    n_missing = int(len(series) * frac)
    idx = rng.choice(series.index, size=n_missing, replace=False)
    series.loc[idx] = np.nan
    return series


def _inject_outliers(series: pd.Series, rng: np.random.Generator, frac: float = 0.01, magnitude: float = 4.0) -> pd.Series:
    series = series.copy()
    valid = series.dropna().index
    n_outliers = max(1, int(len(valid) * frac))
    idx = rng.choice(valid, size=n_outliers, replace=False)
    sign = rng.choice([-1, 1], size=n_outliers)
    series.loc[idx] = series.loc[idx] + sign * magnitude * series.std()
    return series


def generate_solar_generation(seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = _date_index()
    day_of_year = dates.dayofyear.values

    seasonal = 1 + 0.6 * np.sin(2 * np.pi * (day_of_year - 80) / 365.25)
    cloud_cover = np.clip(40 + 25 * np.sin(2 * np.pi * (day_of_year + 30) / 365.25) + rng.normal(0, 12, len(dates)), 0, 100)
    trend = np.linspace(0, 8, len(dates))  # gradual capacity growth
    base = 120 * seasonal * (1 - cloud_cover / 200) + trend
    noise = rng.normal(0, 6, len(dates))
    solar_mwh = np.clip(base + noise, 0, None)

    temperature = 18 + 10 * np.sin(2 * np.pi * (day_of_year - 80) / 365.25) + rng.normal(0, 2.5, len(dates))

    df = pd.DataFrame({
        "date": dates,
        "solar_generation_mwh": solar_mwh.round(2),
        "temperature_c": temperature.round(1),
        "cloud_cover_pct": cloud_cover.round(1),
    })
    df["solar_generation_mwh"] = _inject_outliers(_inject_missing(df.set_index("date")["solar_generation_mwh"], rng), rng).values
    return df


def generate_wind_generation(seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = _date_index()
    day_of_year = dates.dayofyear.values

    seasonal = 1 + 0.35 * np.sin(2 * np.pi * (day_of_year - 300) / 365.25)
    wind_speed = np.clip(7 + 3 * seasonal + rng.normal(0, 1.8, len(dates)), 0, None)
    # Power roughly scales with wind speed cubed (capped), typical turbine behaviour
    wind_mwh = np.clip(0.9 * np.minimum(wind_speed, 14) ** 2.2 + rng.normal(0, 15, len(dates)), 0, None)

    df = pd.DataFrame({
        "date": dates,
        "wind_generation_mwh": wind_mwh.round(2),
        "wind_speed_ms": wind_speed.round(2),
    })
    df["wind_generation_mwh"] = _inject_outliers(_inject_missing(df.set_index("date")["wind_generation_mwh"], rng), rng).values
    return df


def generate_electricity_demand(seed: int = 21) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = _date_index()
    day_of_year = dates.dayofyear.values
    day_of_week = dates.dayofweek.values

    seasonal = 1 + 0.25 * np.sin(2 * np.pi * (day_of_year - 200) / 365.25)  # summer/winter peaks
    weekly = np.where(day_of_week >= 5, 0.88, 1.0)  # lower demand on weekends
    trend = np.linspace(0, 15, len(dates))
    base = 500 * seasonal * weekly + trend
    noise = rng.normal(0, 12, len(dates))
    demand = np.clip(base + noise, 0, None)

    df = pd.DataFrame({"date": dates, "demand_mwh": demand.round(2)})
    df["demand_mwh"] = _inject_missing(df.set_index("date")["demand_mwh"], rng).values
    return df


def generate_energy_prices(seed: int = 99) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = _date_index()
    day_of_year = dates.dayofyear.values

    base_price = 55 + 10 * np.sin(2 * np.pi * (day_of_year - 200) / 365.25)
    trend = np.linspace(0, 20, len(dates))  # inflation / market growth
    electricity_price = base_price + trend + rng.normal(0, 3.5, len(dates))
    solar_price = electricity_price * 0.85 + rng.normal(0, 2, len(dates))
    market_price = electricity_price * 1.1 + rng.normal(0, 4, len(dates))

    df = pd.DataFrame({
        "date": dates,
        "electricity_price": electricity_price.round(2),
        "solar_price": solar_price.round(2),
        "market_price": market_price.round(2),
    })
    df["electricity_price"] = _inject_outliers(
        _inject_missing(df.set_index("date")["electricity_price"], rng), rng, frac=0.008
    ).values
    return df


def generate_weather(seed: int = 55) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = _date_index()
    day_of_year = dates.dayofyear.values

    temperature = 15 + 12 * np.sin(2 * np.pi * (day_of_year - 80) / 365.25) + rng.normal(0, 2, len(dates))
    wind_speed = np.clip(7 + 3 * np.sin(2 * np.pi * (day_of_year - 300) / 365.25) + rng.normal(0, 1.8, len(dates)), 0, None)
    humidity = np.clip(60 - 15 * np.sin(2 * np.pi * (day_of_year - 80) / 365.25) + rng.normal(0, 6, len(dates)), 10, 100)
    pressure = 1013 + 8 * np.sin(2 * np.pi * (day_of_year - 150) / 365.25) + rng.normal(0, 3, len(dates))

    df = pd.DataFrame({
        "date": dates,
        "temperature_c": temperature.round(1),
        "wind_speed_ms": wind_speed.round(2),
        "humidity_pct": humidity.round(1),
        "pressure_hpa": pressure.round(1),
    })
    df["wind_speed_ms"] = _inject_missing(df.set_index("date")["wind_speed_ms"], rng, frac=0.02).values
    return df


GENERATORS = {
    "solar": generate_solar_generation,
    "wind": generate_wind_generation,
    "demand": generate_electricity_demand,
    "prices": generate_energy_prices,
    "weather": generate_weather,
}


def generate_all(output_dir: Path = RAW_DIR, force: bool = False) -> list[str]:
    """Generate every synthetic dataset and write it to output_dir. Returns list of written filenames."""
    output_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for name, fn in GENERATORS.items():
        path = output_dir / f"{name}.csv"
        if path.exists() and not force:
            logger.info("Skipping %s (already exists, use --force to regenerate)", path.name)
            continue
        df = fn()
        df.to_csv(path, index=False)
        logger.info("Generated %s (%d rows)", path.name, len(df))
        written.append(path.name)
    return written
