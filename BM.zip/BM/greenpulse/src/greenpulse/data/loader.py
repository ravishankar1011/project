"""Dataset loading and schema validation (Module 1)."""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from greenpulse.exceptions import DatasetNotFoundError, InvalidDatasetError
from greenpulse.logging_config import get_logger

logger = get_logger("data.loader")

RAW_DIR = Path(__file__).resolve().parents[3] / "data" / "raw"

# Expected schema per named dataset: {column: dtype_kind}. "date" is always required.
SCHEMAS = {
    "solar": {"date": "datetime", "solar_generation_mwh": "numeric", "temperature_c": "numeric", "cloud_cover_pct": "numeric"},
    "wind": {"date": "datetime", "wind_generation_mwh": "numeric", "wind_speed_ms": "numeric"},
    "demand": {"date": "datetime", "demand_mwh": "numeric"},
    "prices": {"date": "datetime", "electricity_price": "numeric", "solar_price": "numeric", "market_price": "numeric"},
    "weather": {"date": "datetime", "temperature_c": "numeric", "wind_speed_ms": "numeric", "humidity_pct": "numeric", "pressure_hpa": "numeric"},
}


class DatasetLoader:
    """Loads a named or arbitrary CSV/Excel dataset and validates it against a schema."""

    def __init__(self, raw_dir: Path = RAW_DIR):
        self.raw_dir = raw_dir

    def available_datasets(self) -> list[str]:
        return sorted(SCHEMAS.keys())

    def resolve_path(self, name_or_path: str) -> Path:
        candidate = Path(name_or_path)
        if candidate.exists():
            return candidate
        for ext in (".csv", ".xlsx"):
            candidate = self.raw_dir / f"{name_or_path}{ext}"
            if candidate.exists():
                return candidate
        raise DatasetNotFoundError(
            f"Could not find dataset '{name_or_path}'. Looked in {self.raw_dir} and as a literal path. "
            f"Available named datasets: {', '.join(self.available_datasets())}. "
            f"Run 'greenpulse generate-data' first if you haven't generated synthetic data."
        )

    def load(self, name_or_path: str, validate: bool = True) -> pd.DataFrame:
        path = self.resolve_path(name_or_path)
        logger.debug("Loading dataset from %s", path)
        try:
            if path.suffix == ".xlsx":
                df = pd.read_excel(path)
            else:
                df = pd.read_csv(path)
        except Exception as exc:  # pandas raises many different error types
            raise InvalidDatasetError(f"Failed to parse '{path}': {exc}") from exc

        if "date" not in df.columns:
            raise InvalidDatasetError(f"Dataset '{path.name}' has no 'date' column.")
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if df["date"].isna().all():
            raise InvalidDatasetError(f"Dataset '{path.name}' has an unparseable 'date' column.")
        df = df.sort_values("date").reset_index(drop=True)
        df = df.set_index("date")

        if validate and path.stem in SCHEMAS:
            self._validate_schema(df, path.stem)

        logger.info("Loaded '%s': %d rows, columns=%s", path.name, len(df), list(df.columns))
        return df

    def _validate_schema(self, df: pd.DataFrame, dataset_name: str) -> None:
        schema = SCHEMAS[dataset_name]
        expected_cols = [c for c in schema if c != "date"]
        missing = [c for c in expected_cols if c not in df.columns]
        if missing:
            raise InvalidDatasetError(
                f"Dataset '{dataset_name}' is missing expected columns: {missing}"
            )
        for col in expected_cols:
            if not pd.api.types.is_numeric_dtype(df[col]):
                raise InvalidDatasetError(
                    f"Column '{col}' in dataset '{dataset_name}' should be numeric but has dtype {df[col].dtype}"
                )
