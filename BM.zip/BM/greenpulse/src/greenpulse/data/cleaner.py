"""Missing value handling and outlier detection (Module 2)."""
from __future__ import annotations

import pandas as pd

from greenpulse.exceptions import InsufficientDataError
from greenpulse.logging_config import get_logger

logger = get_logger("data.cleaner")

MISSING_METHODS = ("ffill", "bfill", "interpolate", "mean", "median", "drop")


class DataCleaner:
    """Cleans a time-indexed DataFrame: fills missing values and flags/handles outliers."""

    def __init__(self, df: pd.DataFrame):
        if df.empty:
            raise InsufficientDataError("Cannot clean an empty dataset.")
        self.df = df.copy()

    def missing_value_report(self) -> pd.Series:
        counts = self.df.isna().sum()
        return counts[counts > 0].sort_values(ascending=False)

    def handle_missing(self, method: str = "interpolate", columns: list[str] | None = None) -> pd.DataFrame:
        if method not in MISSING_METHODS:
            raise ValueError(f"Unknown missing-value method '{method}'. Choose from {MISSING_METHODS}.")

        cols = columns or self.df.select_dtypes("number").columns.tolist()
        before = int(self.df[cols].isna().sum().sum())

        if method == "ffill":
            self.df[cols] = self.df[cols].ffill().bfill()
        elif method == "bfill":
            self.df[cols] = self.df[cols].bfill().ffill()
        elif method == "interpolate":
            self.df[cols] = self.df[cols].interpolate(method="time" if isinstance(self.df.index, pd.DatetimeIndex) else "linear")
            self.df[cols] = self.df[cols].ffill().bfill()
        elif method == "mean":
            self.df[cols] = self.df[cols].fillna(self.df[cols].mean())
        elif method == "median":
            self.df[cols] = self.df[cols].fillna(self.df[cols].median())
        elif method == "drop":
            self.df = self.df.dropna(subset=cols)

        after = int(self.df[cols].isna().sum().sum())
        logger.info("Missing values in %s: %d -> %d (method=%s)", cols, before, after, method)
        return self.df

    def detect_outliers(self, columns: list[str] | None = None, z_thresh: float = 3.0) -> pd.DataFrame:
        """Return a boolean mask DataFrame flagging values beyond z_thresh standard deviations."""
        cols = columns or self.df.select_dtypes("number").columns.tolist()
        z_scores = (self.df[cols] - self.df[cols].mean()) / self.df[cols].std(ddof=0)
        mask = z_scores.abs() > z_thresh
        total = int(mask.sum().sum())
        logger.info("Detected %d outlier values across columns %s (z>%.1f)", total, cols, z_thresh)
        return mask

    def clip_outliers(self, columns: list[str] | None = None, z_thresh: float = 3.0) -> pd.DataFrame:
        """Replace outliers with NaN then interpolate them away."""
        cols = columns or self.df.select_dtypes("number").columns.tolist()
        mask = self.detect_outliers(cols, z_thresh)
        for col in cols:
            self.df.loc[mask[col], col] = pd.NA
        self.df[cols] = self.df[cols].astype(float).interpolate(
            method="time" if isinstance(self.df.index, pd.DatetimeIndex) else "linear"
        ).ffill().bfill()
        return self.df
