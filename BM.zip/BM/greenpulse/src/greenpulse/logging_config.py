import logging
import sys
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parents[2] / "logs"


def setup_logging(verbose: bool = False) -> logging.Logger:
    """Configure and return the GreenPulse root logger.

    Logs to both console (INFO by default, DEBUG if verbose) and to
    logs/greenpulse.log (always DEBUG level, for post-mortem debugging).
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("greenpulse")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    file_handler = logging.FileHandler(LOG_DIR / "greenpulse.log")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"greenpulse.{name}")
