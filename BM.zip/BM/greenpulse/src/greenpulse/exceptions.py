class GreenPulseError(Exception):
    """Base exception for all GreenPulse errors."""


class DatasetNotFoundError(GreenPulseError):
    """Raised when a requested dataset file does not exist."""


class InvalidDatasetError(GreenPulseError):
    """Raised when a dataset fails schema validation."""


class InsufficientDataError(GreenPulseError):
    """Raised when there is not enough data to perform an operation (e.g. forecasting)."""


class ModelNotTrainedError(GreenPulseError):
    """Raised when a prediction is requested before a model has been trained."""


class UnknownModelError(GreenPulseError):
    """Raised when a requested model name is not supported."""
