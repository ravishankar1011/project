"""Green energy price forecasting (Module 3): Linear Regression, Random Forest, XGBoost."""
from __future__ import annotations

import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression

from greenpulse.exceptions import InsufficientDataError, ModelNotTrainedError, UnknownModelError
from greenpulse.forecasting.features import build_features
from greenpulse.forecasting.metrics import evaluate
from greenpulse.logging_config import get_logger

logger = get_logger("forecasting.price")


def _build_xgboost():
    """Imported lazily: xgboost's native library can fail to load (e.g. missing libomp on
    macOS) even when the Python package is installed, so we only pay that cost if xgboost
    is actually requested, and surface a clear error instead of crashing on CLI startup."""
    try:
        from xgboost import XGBRegressor
    except (ImportError, OSError) as exc:
        raise UnknownModelError(
            "xgboost is installed but its native library failed to load "
            f"(commonly missing OpenMP runtime on macOS: run 'brew install libomp'). Details: {exc}"
        ) from exc
    return XGBRegressor(n_estimators=300, max_depth=5, learning_rate=0.05, random_state=42, verbosity=0)


MODEL_REGISTRY = {
    "linear": lambda: LinearRegression(),
    "random_forest": lambda: RandomForestRegressor(n_estimators=300, max_depth=8, random_state=42),
    "xgboost": _build_xgboost,
}

LAGS = (1, 2, 3, 7, 14)


class PriceForecaster:
    """Trains a regression model on a price series and forecasts future values."""

    def __init__(self, model_name: str = "random_forest"):
        if model_name not in MODEL_REGISTRY:
            raise UnknownModelError(f"Unknown model '{model_name}'. Choose from {list(MODEL_REGISTRY)}.")
        self.model_name = model_name
        self.model = MODEL_REGISTRY[model_name]()
        self.feature_columns: list[str] | None = None
        self.metrics: dict | None = None
        self._history: pd.Series | None = None

    def fit(self, series: pd.Series, test_size: float = 0.2) -> dict:
        series = series.dropna()
        if len(series) < 60:
            raise InsufficientDataError(f"Need at least 60 data points to train a price model, got {len(series)}.")

        feat = build_features(series, lags=LAGS).dropna()
        self.feature_columns = [c for c in feat.columns if c != "target"]

        split_idx = int(len(feat) * (1 - test_size))
        train, test = feat.iloc[:split_idx], feat.iloc[split_idx:]

        self.model.fit(train[self.feature_columns], train["target"])
        preds = self.model.predict(test[self.feature_columns])
        self.metrics = evaluate(test["target"], preds)
        self._history = series
        logger.info("Trained %s price model | holdout metrics: %s", self.model_name, self.metrics)
        return self.metrics

    def forecast(self, horizon: int = 7) -> pd.Series:
        if self._history is None:
            raise ModelNotTrainedError("Call fit() before forecast().")

        history = self._history.copy()
        future_index = pd.date_range(history.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
        predictions = []

        working_series = history.copy()
        for date in future_index:
            row = {
                "day_index": len(working_series),
                "day_of_week": date.dayofweek,
                "month": date.month,
                "day_of_year": date.dayofyear,
            }
            for lag in LAGS:
                row[f"lag_{lag}"] = working_series.iloc[-lag] if len(working_series) >= lag else working_series.iloc[0]
            X = pd.DataFrame([row])[self.feature_columns]
            pred = float(self.model.predict(X)[0])
            predictions.append(pred)
            working_series.loc[date] = pred

        return pd.Series(predictions, index=future_index, name=f"{self._history.name}_forecast")
