"""Shared feature engineering for time-indexed forecasting (date parts + lag features)."""
from __future__ import annotations

import pandas as pd


def build_features(series: pd.Series, lags: tuple[int, ...] = (1, 2, 3, 7, 14)) -> pd.DataFrame:
    """Turn a single time-indexed numeric series into a supervised-learning feature frame.

    Columns: day_index, day_of_week, month, day_of_year, lag_1..lag_N, target.
    Rows with any NaN (from the initial lag warm-up) are dropped by the caller via dropna().
    """
    df = pd.DataFrame(index=series.index)
    df["day_index"] = range(len(series))
    df["day_of_week"] = series.index.dayofweek
    df["month"] = series.index.month
    df["day_of_year"] = series.index.dayofyear
    for lag in lags:
        df[f"lag_{lag}"] = series.shift(lag)
    df["target"] = series.values
    return df


FEATURE_COLUMNS_TEMPLATE = ["day_index", "day_of_week", "month", "day_of_year"]
