"""Weather forecasting for windmills (Module 4): Random Forest regression + wind-energy estimation."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

from greenpulse.exceptions import InsufficientDataError, ModelNotTrainedError, UnknownModelError
from greenpulse.forecasting.features import build_features
from greenpulse.forecasting.metrics import evaluate
from greenpulse.logging_config import get_logger

logger = get_logger("forecasting.weather")

MODEL_REGISTRY = {
    "random_forest": lambda: RandomForestRegressor(n_estimators=300, max_depth=8, random_state=42),
}

LAGS = (1, 2, 3, 7)

# Turbine power-curve cutoffs (m/s): below cut-in, no power; capped at rated speed.
CUT_IN_SPEED = 3.0
RATED_SPEED = 14.0
POWER_COEFFICIENT = 0.9


class WeatherForecaster:
    """Trains a regression model to forecast a weather variable (e.g. wind speed) N days ahead."""

    def __init__(self, model_name: str = "random_forest"):
        if model_name not in MODEL_REGISTRY:
            raise UnknownModelError(f"Unknown model '{model_name}'. Choose from {list(MODEL_REGISTRY)}.")
        self.model_name = model_name
        self.model = MODEL_REGISTRY[model_name]()
        self.feature_columns: list[str] | None = None
        self.metrics: dict | None = None
        self._history: pd.Series | None = None

    def fit(self, series: pd.Series, test_size: float = 0.2) -> dict:
        series = series.dropna()
        if len(series) < 60:
            raise InsufficientDataError(f"Need at least 60 data points to train a weather model, got {len(series)}.")

        feat = build_features(series, lags=LAGS).dropna()
        self.feature_columns = [c for c in feat.columns if c != "target"]

        split_idx = int(len(feat) * (1 - test_size))
        train, test = feat.iloc[:split_idx], feat.iloc[split_idx:]

        self.model.fit(train[self.feature_columns], train["target"])
        preds = self.model.predict(test[self.feature_columns])
        self.metrics = evaluate(test["target"], preds)
        self._history = series
        logger.info("Trained %s weather model | holdout metrics: %s", self.model_name, self.metrics)
        return self.metrics

    def forecast(self, horizon: int = 7) -> pd.Series:
        if self._history is None:
            raise ModelNotTrainedError("Call fit() before forecast().")

        history = self._history.copy()
        future_index = pd.date_range(history.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
        predictions = []

        working_series = history.copy()
        for date in future_index:
            row = {
                "day_index": len(working_series),
                "day_of_week": date.dayofweek,
                "month": date.month,
                "day_of_year": date.dayofyear,
            }
            for lag in LAGS:
                row[f"lag_{lag}"] = working_series.iloc[-lag] if len(working_series) >= lag else working_series.iloc[0]
            X = pd.DataFrame([row])[self.feature_columns]
            pred = float(self.model.predict(X)[0])
            predictions.append(pred)
            working_series.loc[date] = pred

        return pd.Series(predictions, index=future_index, name=f"{self._history.name}_forecast")


def estimate_wind_energy(wind_speed: pd.Series) -> pd.Series:
    """Estimate wind-energy generation (MWh) from wind speed using a simplified turbine power curve."""
    speed = wind_speed.clip(lower=0)
    energy = POWER_COEFFICIENT * np.minimum(speed, RATED_SPEED) ** 2.2
    energy = energy.where(speed >= CUT_IN_SPEED, 0.0)
    energy.name = "estimated_wind_energy_mwh"
    return energy.round(2)
