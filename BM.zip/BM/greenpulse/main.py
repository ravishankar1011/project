#!/usr/bin/env python3
"""Entry point for the GreenPulse CLI. Run: python main.py <command> [options]"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from greenpulse.cli import main

if __name__ == "__main__":
    sys.exit(main())
