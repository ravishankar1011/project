# GreenPulse Analytics Platform

A command-line renewable-energy analytics platform: load and validate datasets,
clean and explore time-series data, visualize trends, and forecast electricity
prices and weather/wind conditions.

Covers Milestones 1–4 of the Renewable Energy Analytics roadmap:

| Module | Milestone | Capability |
|---|---|---|
| 1 | CLI Application | Load/validate datasets, view stats, clean data, plot graphs, export results |
| 2 | Time-Series Processing | Missing-value handling, resampling, rolling averages, trend & seasonal decomposition |
| 3 | Market Price Forecasting | Linear Regression / Random Forest / XGBoost, RMSE/MAE/R² |
| 4 | Weather Forecasting for Windmills | Random Forest forecast of wind speed + estimated turbine energy output |

## Setup

```bash
cd greenpulse
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

> **macOS + XGBoost:** if `forecast-price --model xgboost` errors about a missing
> native library, run `brew install libomp` (XGBoost needs the OpenMP runtime).
> `linear` and `random_forest` work without it.

Generate the synthetic datasets (solar, wind, demand, energy prices, weather)
that power every other command:

```bash
python main.py generate-data
```

## Datasets

Named datasets (auto-generated into `data/raw/*.csv`, 3 years of daily data,
with realistic seasonality, trend, injected missing values and outliers):

| Name | Columns |
|---|---|
| `solar` | `solar_generation_mwh`, `temperature_c`, `cloud_cover_pct` |
| `wind` | `wind_generation_mwh`, `wind_speed_ms` |
| `demand` | `demand_mwh` |
| `prices` | `electricity_price`, `solar_price`, `market_price` |
| `weather` | `temperature_c`, `wind_speed_ms`, `humidity_pct`, `pressure_hpa` |

You can also pass any CSV/Excel file path with a `date` column in place of a
named dataset.

## Commands

```bash
python main.py list-datasets

python main.py stats prices --correlation

python main.py clean prices --method interpolate --clip-outliers --export

python main.py analyze solar --column solar_generation_mwh --resample W --rolling 7 --trend

python main.py decompose solar --column solar_generation_mwh --period 365

python main.py plot wind --column wind_generation_mwh --type trend

python main.py forecast-price --model random_forest --horizon 14 --plot --export

python main.py forecast-weather --column wind_speed_ms --model random_forest \
    --horizon 7 --estimate-energy --plot --export

python main.py export prices --format csv
```

Run `python main.py <command> --help` for full options. Add `-v` before the
subcommand for debug logging.

## Project structure

```
greenpulse/
├── main.py                     # entry point
├── src/greenpulse/
│   ├── cli.py                  # argparse subcommands (Module 1)
│   ├── exceptions.py           # typed exception hierarchy
│   ├── logging_config.py       # console + file logging
│   ├── data/
│   │   ├── generator.py        # synthetic dataset generation
│   │   ├── loader.py           # CSV/Excel loading + schema validation
│   │   └── cleaner.py          # missing values + outlier detection (Module 2)
│   ├── analytics/
│   │   ├── stats.py            # describe(), correlation
│   │   ├── timeseries.py       # resample, rolling avg, trend, decomposition
│   │   └── visualization.py    # matplotlib plotting -> outputs/plots
│   ├── forecasting/
│   │   ├── features.py         # shared date/lag feature engineering
│   │   ├── metrics.py          # RMSE / MAE / R²
│   │   ├── price_forecaster.py # Module 3
│   │   └── weather_forecaster.py # Module 4 + wind-energy estimation
│   └── export/
│       └── exporter.py         # CSV/JSON export (Module 1)
├── data/{raw,processed}/
├── outputs/{plots,reports,models}/
└── logs/greenpulse.log
```

## Notes on forecasting quality

The synthetic price series has a genuinely linear trend, so `linear` regression
scores best in the demo holdout; `random_forest`/`xgboost` tend to underperform
because tree-based models can't extrapolate a trend beyond the training range —
this is a real, well-known limitation of tree ensembles on trending time series,
not a bug. Swap in real datasets and re-run `stats`/`analyze` to see which model
fits your actual data best. LSTM was intentionally left out (marked optional in
the spec) to avoid a heavy TensorFlow/PyTorch dependency; `forecasting/features.py`
is the place to plug it in if needed later.
